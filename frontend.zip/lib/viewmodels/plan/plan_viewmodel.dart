import 'package:flutter/foundation.dart';
import '../../data/plan/plan_repository.dart';
import '../../models/plan/plan_models.dart';

enum PlanVmState { idle, loading, success, error }

class PlanViewModel extends ChangeNotifier {
  final PlanRepository _repo;

  PlanViewModel({PlanRepository? repository})
    : _repo = repository ?? PlanRepository();

  // ── Plans list ─────────────────────────────────────────────────────────────
  List<ActivePlan> plans = [];
  PlanVmState listState = PlanVmState.idle;
  String? listError;

  // ── Enroll / first payment ─────────────────────────────────────────────────
  PlanVmState enrollState = PlanVmState.idle;
  String? enrollError;
  ActivePlan? enrolledPlan;

  // ── Monthly instalment ─────────────────────────────────────────────────────
  PlanVmState payState = PlanVmState.idle;
  String? payError;
  PlanPaymentResponse? paymentResult;

  // ── ROI withdrawal ─────────────────────────────────────────────────────────
  PlanVmState roiState = PlanVmState.idle;
  String? roiError;
  RoiWithdrawalResponse? roiResult;

  // ── Principal withdrawal ───────────────────────────────────────────────────
  PlanVmState principalState = PlanVmState.idle;
  String? principalError;
  PrincipalWithdrawalResponse? principalResult;

  // ── Profile plan amount ────────────────────────────────────────────────────
  double planAmount = 0;

  // ── Wallet balance ─────────────────────────────────────────────────────────
  double walletBalance = 0;
  PlanVmState walletBalanceState = PlanVmState.idle;

  // ── Load plans ─────────────────────────────────────────────────────────────
  Future<void> loadPlans() async {
    listState = PlanVmState.loading;
    listError = null;
    notifyListeners();

    try {
      plans = await _repo.fetchMyPlans();
      _recomputePlanAmountLocally();
      listState = PlanVmState.success;
    } catch (e) {
      listError = e.toString().replaceFirst('Exception: ', '');
      listState = PlanVmState.error;
    }
    notifyListeners();
  }

  // ── Profile plan amount ────────────────────────────────────────────────────
  Future<void> loadPlanAmount() async {
    try {
      planAmount = await _repo.fetchPlanAmount();
    } catch (_) {
      _recomputePlanAmountLocally();
    }
    notifyListeners();
  }

  void _recomputePlanAmountLocally() {
    double total = 0;
    for (final p in plans) {
      if (p.status == PlanStatus.active ||
          p.status == PlanStatus.approved ||
          p.status == PlanStatus.completed) {
        total += p.totalPrincipal;
      }
    }
    planAmount = total;
  }

  // ── Load wallet balance ────────────────────────────────────────────────────
  Future<void> loadWalletBalance() async {
    walletBalanceState = PlanVmState.loading;
    notifyListeners();
    try {
      walletBalance = await _repo.fetchWalletBalance();
      walletBalanceState = PlanVmState.success;
    } catch (_) {
      walletBalance = 0;
      walletBalanceState = PlanVmState.error;
    }
    notifyListeners();
  }

  // ── Queries ────────────────────────────────────────────────────────────────
  bool hasActivePlan(PlanType type) {
    return plans.any(
      (p) =>
          p.planType == type &&
          (p.status == PlanStatus.active ||
              p.status == PlanStatus.approved ||
              p.status == PlanStatus.underReview),
    );
  }

  ActivePlan? getActivePlan(PlanType type) {
    try {
      return plans.firstWhere(
        (p) =>
            p.planType == type &&
            (p.status == PlanStatus.active ||
                p.status == PlanStatus.approved ||
                p.status == PlanStatus.underReview),
      );
    } catch (_) {
      return null;
    }
  }

  List<ActivePlan> getPlansForType(PlanType type) =>
      plans.where((p) => p.planType == type).toList();

  // ── Enroll via UPI (first payment, requires admin approval) ───────────────
  Future<void> enrollPlan({
    required PlanType planType,
    required int monthlyAmount,
    required String utrId,
    required String proofImageUrl,
  }) async {
    enrollState = PlanVmState.loading;
    enrollError = null;
    enrolledPlan = null;
    notifyListeners();

    try {
      enrolledPlan = await _repo.enrollPlan(
        planType: planType,
        monthlyAmount: monthlyAmount,
        utrId: utrId,
        proofImageUrl: proofImageUrl,
      );
      plans.add(enrolledPlan!);
      _recomputePlanAmountLocally();
      enrollState = PlanVmState.success;
    } catch (e) {
      enrollError = e.toString().replaceFirst('Exception: ', '');
      enrollState = PlanVmState.error;
    }
    notifyListeners();
  }

  // ── Enroll via Wallet (instant — no admin approval) ───────────────────────
  Future<void> enrollPlanWithWallet({
    required PlanType planType,
    required int monthlyAmount,
  }) async {
    enrollState = PlanVmState.loading;
    enrollError = null;
    enrolledPlan = null;
    notifyListeners();

    try {
      enrolledPlan = await _repo.enrollPlanWithWallet(
        planType: planType,
        monthlyAmount: monthlyAmount,
      );
      plans.add(enrolledPlan!);
      _recomputePlanAmountLocally();
      enrollState = PlanVmState.success;
    } catch (e) {
      enrollError = e.toString().replaceFirst('Exception: ', '');
      enrollState = PlanVmState.error;
    }
    notifyListeners();
  }

  // ── Monthly instalment via UPI ─────────────────────────────────────────────
  Future<void> payMonthlyInstalment({
    required String planId,
    required String utrId,
    required String proofImageUrl,
  }) async {
    payState = PlanVmState.loading;
    payError = null;
    paymentResult = null;
    notifyListeners();

    try {
      paymentResult = await _repo.payMonthlyInstalment(
        planId: planId,
        utrId: utrId,
        proofImageUrl: proofImageUrl,
      );
      payState = PlanVmState.success;
      await loadPlans();
    } catch (e) {
      payError = e.toString().replaceFirst('Exception: ', '');
      payState = PlanVmState.error;
    }
    notifyListeners();
  }

  // ── Monthly instalment via Wallet (instant — no admin approval) ────────────
  Future<void> payMonthlyInstalmentWithWallet({required String planId}) async {
    payState = PlanVmState.loading;
    payError = null;
    paymentResult = null;
    notifyListeners();

    try {
      paymentResult = await _repo.payMonthlyInstalmentWithWallet(
        planId: planId,
      );
      payState = PlanVmState.success;
      await loadPlans();
    } catch (e) {
      payError = e.toString().replaceFirst('Exception: ', '');
      payState = PlanVmState.error;
    }
    notifyListeners();
  }

  // ── ROI withdrawal ─────────────────────────────────────────────────────────
  Future<void> withdrawRoi({
    required String planId,
    required double amount,
  }) async {
    roiState = PlanVmState.loading;
    roiError = null;
    roiResult = null;
    notifyListeners();

    try {
      roiResult = await _repo.withdrawRoi(planId: planId, amount: amount);
      roiState = PlanVmState.success;
      await loadPlans();
    } catch (e) {
      roiError = e.toString().replaceFirst('Exception: ', '');
      roiState = PlanVmState.error;
    }
    notifyListeners();
  }

  // ── Principal withdrawal ───────────────────────────────────────────────────
  Future<void> withdrawPrincipal({required String planId}) async {
    principalState = PlanVmState.loading;
    principalError = null;
    principalResult = null;
    notifyListeners();

    try {
      principalResult = await _repo.withdrawPrincipal(planId: planId);
      principalState = PlanVmState.success;
      await loadPlans();
    } catch (e) {
      principalError = e.toString().replaceFirst('Exception: ', '');
      principalState = PlanVmState.error;
    }
    notifyListeners();
  }

  // ── Upload proof ───────────────────────────────────────────────────────────
  Future<String?> uploadProof(List<int> bytes, String filename) async {
    try {
      return await _repo.uploadProof(bytes, filename);
    } catch (_) {
      return null;
    }
  }

  // ── Resets ─────────────────────────────────────────────────────────────────
  void resetEnroll() {
    enrollState = PlanVmState.idle;
    enrollError = null;
    enrolledPlan = null;
    notifyListeners();
  }

  void resetPay() {
    payState = PlanVmState.idle;
    payError = null;
    paymentResult = null;
    notifyListeners();
  }

  void resetRoi() {
    roiState = PlanVmState.idle;
    roiError = null;
    roiResult = null;
    notifyListeners();
  }

  void resetPrincipal() {
    principalState = PlanVmState.idle;
    principalError = null;
    principalResult = null;
    notifyListeners();
  }
}
